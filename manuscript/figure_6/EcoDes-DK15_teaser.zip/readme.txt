EcoDes-DK15 v1.0.0 teaser / sample data set - "Husby Klit" - Jul 2021
Jakob J. Assmann, Jesper E. Moeslund, Urs A. Treier and Signe Normand

Subsample of the EcoDes-DK15 data set for demonstration purposes. 

This data is freely available via a Creative Commons by Attribution 4.0 license.

For the full dataset and documentation, and information on how to cite this data please see:

https://doi.org/10.5281/zenodo.4756556
https://github.com/jakobjassmann/ecodes-dk-lidar